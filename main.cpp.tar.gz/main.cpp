#include <unistd.h>
#include <netdb.h>
#include <dirent.h>
#include <fcntl.h>

#include <sys/stat.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <sys/wait.h>
#include <sys/param.h>
#include <sys/ioctl.h>

#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include <fstream>
#include <iostream>
#include <string>
#include <map>

char pipebuf[0xF00];

const char
  *bot_owner = "bot_owner:uwanosora",
  *nick = "keisan-kun",
  *serv = "irc.livedoor.ne.jp",
  *chan = "#$BJI:]%R%C%-!<(B";

size_t w(std::string name, std::string command){
  using namespace std;
  if(command == "clear"){
    ofstream file(name.c_str());
    return 0;
  }

  {
    fstream file(name.c_str(), ios::out | ios::app | ios::ate);
    file << command << std::endl;
  }

  string redirect = "./w < ";
  redirect += name;
  FILE *fp = popen(redirect.c_str(), "r");

  size_t i = 0;
  char c;
  do{
    if(i > sizeof(pipebuf)){
      sprintf(pipebuf, ">_<\n");
      i = 5;
      break;
    }
    fread((void*)&c, 1, 1, fp);
    pipebuf[i++] = c;
  }while(c != '\n');
  pclose(fp);

  return i;
}

int main(int argc, char *argv[]) {
  int ret;
  char buf[512];
  int sock;
  struct addrinfo hints, *ai;
  memset(&hints, 0, sizeof(struct addrinfo));
  hints.ai_family = AF_UNSPEC;
  hints.ai_socktype = SOCK_STREAM;
  hints.ai_protocol = IPPROTO_TCP;
  if (ret = getaddrinfo(serv, "6667", &hints, &ai)) {
    puts(gai_strerror(ret));
    return 1;
  }
  sock = socket(ai->ai_family, ai->ai_socktype, ai->ai_protocol);
  if (ret = connect(sock, ai->ai_addr, ai->ai_addrlen)) {
    puts(gai_strerror(ret));
    return 1;
  }
  freeaddrinfo(ai);
  sprintf(buf, "USER %s 0 * :%s\r\n", nick, bot_owner);
  send(sock, buf, strlen(buf), 0);
  sprintf(buf, "NICK %s\r\n", nick);
  send(sock, buf, strlen(buf), 0);
  while (recv(sock, buf, 512, 0) > 0) {
    fputs(buf, stdout);
    if (!strncmp(buf, "PING ", 5)) {
      buf[1] = 'O';
      send(sock, buf, strlen(buf), 0);
      continue;
    }
    if (buf[0] != ':') continue;
    if (!strncmp(strchr(buf, ' ') + 1, "001", 3)) {
      sprintf(buf, "MODE %s +B\r\nJOIN %s\r\n", nick, chan);
      send(sock, buf, strlen(buf), 0);
      continue;
    }
    if (!strncmp(strchr(buf, ' ') + 1, "PRIVMSG", 7)) {
      const char
        *command = strchr(buf + 1, ':') + 1,
        *name_begin = strchr(command + 1, ':') + 1,
        *name_end = strchr(name_begin + 1, ' ');
      if (strncmp(command, "w ", 2)) continue;
      command = command + 2;
      size_t n = w(std::string(name_begin, name_end), command);
      if (n > 0) {
        std::string output;
        output += "NOTICE ";
        output += chan;
        output += " :";
        output += pipebuf;
        output += "\r\n";
        send(sock, output.c_str(), output.size(), 0);
      }
      continue;
    }
  }
  close(sock);
  return 0;
}